#!/usr/bin/env python3
"""
Generador de carga de circuito abierto (open-loop) para el Game Day.
Sustituye a k6 en el sandbox: tasa de llegada constante, independiente de la
latencia de respuesta -- imprescindible para que una degradacion no se
auto-oculte reduciendo la carga ofrecida.

Salida: CSV con una fila por peticion -> ts_epoch, latency_ms, status, error
"""
import argparse
import csv
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from queue import Queue

import httpx

p = argparse.ArgumentParser()
p.add_argument("--url", default="http://127.0.0.1:8000")
p.add_argument("--rps", type=float, default=40.0)
p.add_argument("--duration", type=int, default=420)
p.add_argument("--out", default="results/requests.csv")
p.add_argument("--workers", type=int, default=120)
args = p.parse_args()

rows = Queue()
stop = threading.Event()
client = httpx.Client(timeout=15.0, limits=httpx.Limits(max_connections=400))


def fire():
    item = random.randint(1, 5)
    qty = random.randint(1, 10)
    t0 = time.perf_counter()
    ts = time.time()
    try:
        r = client.get(f"{args.url}/api/orders/{item}?qty={qty}")
        code, err = r.status_code, ""
    except Exception as exc:                     # timeout, connection reset...
        code, err = 0, type(exc).__name__
    rows.put((round(ts, 3), round((time.perf_counter() - t0) * 1000, 2), code, err))


def main():
    pool = ThreadPoolExecutor(max_workers=args.workers)
    interval = 1.0 / args.rps
    start = time.time()
    n = 0
    while time.time() - start < args.duration:
        pool.submit(fire)
        n += 1
        nxt = start + n * interval
        d = nxt - time.time()
        if d > 0:
            time.sleep(d)
    pool.shutdown(wait=True)
    with open(args.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ts", "latency_ms", "status", "error"])
        while not rows.empty():
            w.writerow(rows.get())
    print(f"loadgen: {n} peticiones enviadas en {args.duration}s -> {args.out}")


main()
