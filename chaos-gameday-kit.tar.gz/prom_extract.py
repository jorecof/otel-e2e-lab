#!/usr/bin/env python3
"""Extrae los SLIs desde Prometheus para la ventana de un experimento."""
import json
import math
import sys

import httpx

exp = sys.argv[1]
tl = json.load(open(f"results/{exp}_timeline.json"))
ev = tl["events"]
t0, t1 = ev[0]["ts"] - 30, ev[-1]["ts"]
TA = 'http_target="/api/orders/{item_id}"'
TB = 'http_target="/items/{item_id}"'
Q = {
 "p50_a": f'histogram_quantile(0.50, sum by (le) (rate(http_server_duration_milliseconds_bucket{{job="service-a",{TA}}}[60s])))',
 "p95_a": f'histogram_quantile(0.95, sum by (le) (rate(http_server_duration_milliseconds_bucket{{job="service-a",{TA}}}[60s])))',
 "p99_a": f'histogram_quantile(0.99, sum by (le) (rate(http_server_duration_milliseconds_bucket{{job="service-a",{TA}}}[60s])))',
 "p95_b": f'histogram_quantile(0.95, sum by (le) (rate(http_server_duration_milliseconds_bucket{{job="service-b",{TB}}}[60s])))',
 "tput_a": f'sum(rate(http_server_duration_milliseconds_count{{job="service-a",{TA}}}[60s]))',
 "tput_b": f'sum(rate(http_server_duration_milliseconds_count{{job="service-b",{TB}}}[60s]))',
 "err_a": f'sum(rate(http_server_duration_milliseconds_count{{job="service-a",{TA},http_status_code!="200"}}[60s])) or vector(0)',
 "inflight_a": 'sum(http_server_active_requests{job="service-a"})',
 "inflight_b": 'sum(http_server_active_requests{job="service-b"})',
 "orders_ok": 'sum(rate(orders_processed_total[60s]))',
}
out = {}
for k, q in Q.items():
    r = httpx.get("http://127.0.0.1:9090/api/v1/query_range",
                  params={"query": q, "start": t0, "end": t1, "step": "10"}, timeout=30).json()
    res = r["data"]["result"]
    vals = [[float(a), float(b)] for a, b in res[0]["values"]] if res else []
    out[k] = [[a, b] for a, b in vals if not math.isnan(b)]

fases = [(e["event"], e["ts"]) for e in ev if e["event"] in
         ("INICIO", "FASE_1", "FASE_2", "ROLLBACK", "ABORT_CONDITION", "RECUPERACION", "FIN")]
print(f"{'metrica':<12}" + "".join(f"{n[:9]:>12}" for n, _ in fases[:-1]))
tabla = {}
for k, v in out.items():
    fila = []
    for i, (n, a) in enumerate(fases[:-1]):
        b = fases[i + 1][1]
        w = [x[1] for x in v if a <= x[0] < b]
        fila.append(round(max(w), 1) if w else None)
    tabla[k] = fila
    print(f"{k:<12}" + "".join(f"{('-' if x is None else x):>12}" for x in fila))
json.dump({"series": out, "fases": fases, "max_por_fase": tabla},
          open(f"results/{exp}_prom.json", "w"), indent=1)
print(f"\n-> results/{exp}_prom.json  (valores = maximo por fase)")
