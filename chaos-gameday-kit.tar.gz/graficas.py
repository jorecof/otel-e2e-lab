#!/usr/bin/env python3
"""Figuras del Plan de Game Day. Paleta validada (dataviz), superficie clara."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"       # slots categoricos 1-3
CRIT = "#d03b3b"
SURF, INK, SEC, MUT, GRID, BASE = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5,
    "figure.facecolor": SURF, "axes.facecolor": SURF,
    "axes.edgecolor": BASE, "axes.labelcolor": SEC, "text.color": INK,
    "xtick.color": MUT, "ytick.color": MUT, "grid.color": GRID,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.linewidth": 0.6, "axes.linewidth": 0.8,
})


def load(exp):
    a = json.load(open(f"results/{exp}_analisis.json"))
    p = json.load(open(f"results/{exp}_prom.json"))
    return a, p


def fases(a):
    """(nombre, t_rel_ini, t_rel_fin) de cada fase, en segundos desde el inicio."""
    t0 = a["t0"]
    return [(f["fase"], f["t_ini"] - t0, f["t_fin"] - t0) for f in a["resumen"]]


def sombrear(ax, a, etiquetar=True):
    for name, ini, fin in fases(a):
        if name.startswith("FASE"):
            ax.axvspan(ini, fin, color=CRIT, alpha=0.07, zorder=0)
            ax.axvline(ini, color=CRIT, lw=0.9, ls=(0, (4, 3)), zorder=1)
        if name in ("RECUPERACION",):
            ax.axvline(ini, color=BASE, lw=0.9, ls=(0, (4, 3)), zorder=1)


ms = FuncFormatter(lambda v, _: f"{v/1000:.1f} s".replace(".0 s", " s") if v >= 1000 else f"{v:g} ms")

# ---------------------------------------------------------------- Figura 1
a1, p1 = load("exp1")
t = [s["t"] for s in a1["serie"]]
p50 = [s["p50"] for s in a1["serie"]]
p95 = [s["p95"] for s in a1["serie"]]

fig, ax = plt.subplots(figsize=(6.6, 2.9))
sombrear(ax, a1)
ax.axhline(250, color=MUT, lw=1.0, ls=(0, (2, 2)), zorder=1)
ax.text(4, 265, "SLO de latencia: p95 ≤ 250 ms", color=SEC, fontsize=7.5, va="bottom")
ax.plot(t, p95, color=S2, lw=2, zorder=3)
ax.plot(t, p50, color=S1, lw=2, zorder=3)
ax.set_yscale("log")
ax.yaxis.set_major_formatter(ms)
ax.set_ylim(8, 12000)
ax.set_xlim(0, max(t))
ax.set_xlabel("segundos desde el inicio del Game Day")
ax.set_ylabel("latencia extremo a extremo")
ax.text(t[-1] + 4, p95[-1], "p95", color=S2, fontsize=8.5, fontweight="bold", va="center")
ax.text(t[-1] + 4, p50[-1] * 0.72, "p50", color=S1, fontsize=8.5, fontweight="bold", va="center")
for name, ini, fin in fases(a1):
    lbl = {"INICIO": "estado estable", "FASE_1": "inyección 400 ms",
           "FASE_2": "inyección 2 500 ms", "RECUPERACION": "tras el rollback"}.get(name)
    if lbl:
        ax.text((ini + fin) / 2, 9500, lbl, ha="center", color=SEC, fontsize=7.5)
ax.set_title("Experimento 1 — la latencia inyectada se propaga al cliente y se amplifica",
             color=INK, fontsize=9, fontweight="bold", loc="left", pad=10)
fig.tight_layout()
fig.savefig("results/fig1_latencia.png", dpi=200)

# ---------------------------------------------------------------- Figura 2
fig, axes = plt.subplots(2, 1, figsize=(6.6, 3.6), sharex=True)
inf = p1["series"]["inflight_a"]
pb = p1["series"]["p95_b"]
t0 = a1["t0"]
axes[0].plot([x[0] - t0 for x in inf], [x[1] for x in inf], color=S1, lw=2, zorder=3)
axes[0].axhline(80, color=MUT, lw=1.0, ls=(0, (2, 2)))
axes[0].text(4, 84, "capacidad del pool de hilos de service-a (2 × 40)", color=SEC, fontsize=7.5)
axes[0].set_ylabel("peticiones en vuelo\nen service-a")
axes[1].plot([x[0] - t0 for x in pb], [x[1] for x in pb], color=S3, lw=2, zorder=3)
axes[1].set_ylabel("p95 de service-b\n(su propio trabajo)")
axes[1].yaxis.set_major_formatter(ms)
axes[1].set_xlabel("segundos desde el inicio del Game Day")
for ax in axes:
    sombrear(ax, a1)
    ax.set_xlim(0, max(t))
axes[0].text(0.985, 0.86, "saturación", transform=axes[0].transAxes, ha="right",
             color=S1, fontsize=8.5, fontweight="bold")
axes[1].text(0.985, 0.80, "dependencia sana", transform=axes[1].transAxes, ha="right",
             color=S3, fontsize=8.5, fontweight="bold")
axes[0].set_title("La saturación ocurre aguas arriba: service-b nunca se degrada",
                  color=INK, fontsize=9.5, fontweight="bold", loc="left", pad=10)
fig.tight_layout()
fig.savefig("results/fig2_saturacion.png", dpi=200)

# ---------------------------------------------------------------- Figura 3
a2, _ = load("exp2")
a3, _ = load("exp3")
grupos = ["E1 · latencia", "E2 · CPU", "E3 · partición"]
est_p95, iny_p95, est_d, iny_d = [], [], [], []
for a in (a1, a2, a3):
    base = a["resumen"][0]
    peor = max((f for f in a["resumen"] if f["fase"].startswith("FASE")), key=lambda f: f["p95"])
    est_p95.append(base["p95"]); iny_p95.append(peor["p95"])
    est_d.append(base["ok_pct"]); iny_d.append(peor["ok_pct"])

fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.5))
x = [0, 1, 2]
w = 0.36
for ax, est, iny, fmt, slo in (
        (axes[0], est_p95, iny_p95, lambda v: ms(v, None), 250),
        (axes[1], est_d, iny_d, lambda v: f"{v:g} %", 99.5)):
    ax.bar([i - w / 2 for i in x], est, width=w - 0.02, color=S1, zorder=3, label="estado estable")
    ax.bar([i + w / 2 for i in x], iny, width=w - 0.02, color=S2, zorder=3, label="bajo inyección")
    ax.axhline(slo, color=MUT, lw=1.0, ls=(0, (2, 2)))
    ax.set_xticks(x); ax.set_xticklabels(grupos, fontsize=7.5, color=SEC)
    ax.grid(axis="x", visible=False)
axes[0].set_yscale("log"); axes[0].yaxis.set_major_formatter(ms); axes[0].set_ylim(8, 90000)
for i in x:
    axes[0].text(i - w / 2, est_p95[i] * 1.25, ms(est_p95[i], None), ha="center", color=SEC, fontsize=7)
    axes[0].text(i + w / 2, iny_p95[i] * 1.25, ms(iny_p95[i], None), ha="center", color=SEC, fontsize=7)
    axes[1].text(i - w / 2, est_d[i] + 3, f"{est_d[i]:g} %", ha="center", color=SEC, fontsize=7)
    axes[1].text(i + w / 2, iny_d[i] + 3, f"{iny_d[i]:g} %", ha="center", color=SEC, fontsize=7)
axes[1].set_ylim(0, 118)
axes[0].set_title("Latencia p95  (SLO ≤ 250 ms)", color=INK, fontsize=8.5, fontweight="bold", loc="left")
axes[1].set_title("Disponibilidad  (SLO ≥ 99,5 %)", color=INK, fontsize=8.5, fontweight="bold", loc="left")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, frameon=False, fontsize=7.5, ncol=2, loc="upper right",
           bbox_to_anchor=(1.0, 1.005), labelcolor=SEC)
fig.suptitle("Cada experimento rompe un SLI distinto", color=INK, fontsize=9,
             fontweight="bold", x=0.01, ha="left", y=0.995)
fig.tight_layout(rect=(0, 0, 1, 0.88))
fig.savefig("results/fig3_comparativa.png", dpi=200)
print("figuras generadas")
