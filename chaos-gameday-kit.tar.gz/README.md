# Kit de Game Day — Chaos Engineering sobre `otel-e2e-lab`

Todo lo necesario para reproducir los tres experimentos del Plan de Game Day.
Los resultados incluidos en `results/` son los reales de la ejecución del 29/08/2026.

## Contenido

| Archivo | Qué hace |
|---|---|
| `loadgen.py` | Generador de carga de **circuito abierto** (tasa de llegada constante). Sustituye a k6 sin dependencias externas. Sin esto, una degradación se auto-oculta: al bajar el throughput baja la carga ofrecida y la latencia parece recuperarse. |
| `exp1_latency.py` | E1 — latencia de red en el enlace `service-a → service-b`. Escalada 400 ms → 2 500 ms, watchdog de canario y doble rollback. |
| `exp2_cpu.py` | E2 — agotamiento de CPU en `service-b` con `stress-ng` dentro de un cgroup con cuota de 1 vCPU. |
| `exp3_partition.py` | E3 — partición de red silenciosa (`iptables -j DROP`) entre `service-b` y PostgreSQL. |
| `analizar.py` | SLIs medidos en el cliente por fase (p50/p95/p99, disponibilidad, throughput). |
| `prom_extract.py` | SLIs desde Prometheus (latencia, throughput, errores, saturación) para la ventana del experimento. |
| `graficas.py` | Figuras 1–3 del documento. |
| `results/` | CSV por petición, timelines JSON, series de Prometheus, figuras y la traza lenta de Jaeger. |

## Cómo ejecutarlo sobre tu lab en OrbStack

```bash
cd deploy/local && docker compose up -d --build
```

**E1 — latencia (con `tc netem`, que sí está disponible en contenedores Linux):**

```bash
# el contenedor necesita NET_ADMIN; añade a service-b en el compose:
#   cap_add: [NET_ADMIN]
docker compose exec service-b tc qdisc add dev eth0 root \
    netem delay 400ms 100ms distribution normal
# ... 90 s ...
docker compose exec service-b tc qdisc add dev eth0 root \
    netem delay 2500ms 500ms distribution normal     # fase 2 (usar `change` si ya existe)
docker compose exec service-b tc qdisc del dev eth0 root      # ROLLBACK
```

En el sandbox donde se ejecutó el Game Day el kernel no exponía `sch_netem`, por eso
`exp1_latency.py` usa Toxiproxy. El modelo (delay + jitter sobre el enlace) es el mismo;
en tu lab prefiere `tc netem`, que es la herramienta que pide la actividad.

**E2 — CPU:**

```bash
docker compose exec service-b sh -c 'apk add --no-cache stress-ng || apt-get install -y stress-ng'
docker update --cpus 1 otel-e2e-lab-service-b-1        # acota el blast radius
docker compose exec -d service-b stress-ng --cpu 4 --cpu-method matrixprod --timeout 120s
```

**E3 — partición hacia PostgreSQL:**

```bash
docker compose exec service-b iptables -A OUTPUT -p tcp --dport 5432 -j DROP
docker compose exec service-b iptables -D OUTPUT -p tcp --dport 5432 -j DROP   # ROLLBACK
```

**Carga y análisis (en los tres casos):**

```bash
python3 loadgen.py --rps 40 --duration 420 --out results/exp1_requests.csv &
python3 exp1_latency.py                 # o dispara la inyección a mano con los comandos de arriba
python3 analizar.py exp1 results/exp1_requests.csv
python3 prom_extract.py exp1
python3 graficas.py
```

## Reglas del Game Day

1. Nunca en producción sin plan de Game Day y rollback definido.
2. Toda inyección lleva **dos** mecanismos de reversión: temporizador duro y watchdog con
   condición de parada explícita.
3. El radio de impacto se declara **y se verifica** (namespace, cgroup o filtro por puerto),
   no se asume.
4. Primero la hipótesis, después el fallo. Un experimento sin predicción previa no enseña nada.

## Hallazgos abiertos (pendientes de remediación)

- **D1** Sin presupuesto de tiempo por salto: `httpx.Client(timeout=10.0)` frente a un p99 real de 36 ms.
- **D2** El SLI de disponibilidad es ciego a la degradación por latencia (0 errores en 180 s de incidente).
- **D3** `except OperationalError → 503` es código muerto: falta `connect_timeout` / `statement_timeout`.
- **D4** Sin bulkhead ni control de admisión: una dependencia lenta consume el pool de hilos completo.
