#!/usr/bin/env python3
"""
EXPERIMENTO 3 -- Network partition entre service-b y PostgreSQL.

Fallo         : particion de red (no caida del proceso). Los paquetes hacia el
                puerto 5432 se descartan con DROP -- no con REJECT -- para
                reproducir el caso realista de un security group / NetworkPolicy
                mal aplicado, en el que el cliente no recibe RST y espera.
Inyector      : iptables dentro del network namespace `svcb`.
Blast radius  : unicamente el trafico saliente de service-b hacia 5432. El resto
                del stack (incluido el propio Postgres, que sigue vivo) no se toca.
Duracion      : 60 s estado estable | 90 s particion | 90 s recuperacion.
Rollback      : temporizador duro (borrado de la regla) + watchdog canary.
"""
import json
import subprocess
import threading
import time

import httpx

RULE = "OUTPUT -p tcp --dport 5432 -j DROP"
CANARY = "http://127.0.0.1:8000/api/orders/1?qty=1"
EVENTS, CANARY_LOG = [], []
ABORT = threading.Event()


def ev(name, detail=""):
    e = {"ts": round(time.time(), 3), "iso": time.strftime("%H:%M:%S"),
         "event": name, "detail": detail}
    EVENTS.append(e)
    print(f"[{e['iso']}] {name} {detail}", flush=True)


def sh(c):
    r = subprocess.run(c, shell=True, capture_output=True, text=True)
    return (r.stdout + r.stderr).strip()


def inject():
    sh(f"ip netns exec svcb iptables -A {RULE}")
    ev("INYECCION", f"regla activa -> {sh('ip netns exec svcb iptables -S OUTPUT')}")


def rollback(reason=""):
    sh(f"ip netns exec svcb iptables -D {RULE}")
    ev("ROLLBACK", f"{reason} | reglas: {sh('ip netns exec svcb iptables -S OUTPUT')}")


def watchdog():
    c = httpx.Client(timeout=15.0)
    fails = 0
    while not ABORT.is_set():
        t0 = time.perf_counter()
        try:
            code = c.get(CANARY).status_code
        except Exception:
            code = 0
        lat = (time.perf_counter() - t0) * 1000
        CANARY_LOG.append({"ts": round(time.time(), 2), "status": code, "latency_ms": round(lat, 1)})
        # En este experimento se ESPERA error; la condicion de parada vigila que
        # la degradacion no exceda la ventana pactada.
        fails = fails + 1 if (code != 200 or lat > 12000) else 0
        if fails >= 45:
            ev("ABORT_CONDITION", "degradacion sostenida por encima de la ventana pactada")
            rollback("disparado por el watchdog")
            ABORT.set()
            return
        time.sleep(2)


def main():
    threading.Thread(target=watchdog, daemon=True).start()
    ev("INICIO", "estado estable")
    for _ in range(60):
        if ABORT.is_set():
            break
        time.sleep(1)
    ev("FASE_1", "particion de red service-b -> PostgreSQL")
    inject()
    for _ in range(90):
        if ABORT.is_set():
            break
        time.sleep(1)
    if not ABORT.is_set():
        rollback("fin de la ventana programada")
    ABORT.set()
    ev("RECUPERACION", "observando el retorno al estado estable")
    time.sleep(90)
    ev("FIN", "")
    json.dump({"events": EVENTS, "canary": CANARY_LOG},
              open("results/exp3_timeline.json", "w"), indent=1, ensure_ascii=False)


main()
