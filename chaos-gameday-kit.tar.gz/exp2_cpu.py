#!/usr/bin/env python3
"""
EXPERIMENTO 2 -- Resource exhaustion (CPU) en el servicio de inventario.

Fallo         : agotamiento de CPU en service-b.
Inyector      : stress-ng 0.17.06, ejecutado DENTRO del mismo cgroup de CPU que
                los procesos de service-b, de modo que compite por la misma
                cuota y no degrada al resto del stack.
Blast radius  : cgroup /sys/fs/cgroup/cpu/svcb con cuota de 1 CPU, que contiene
                unicamente los 3 procesos de service-b y los trabajadores de
                stress-ng. service-a, Postgres, Collector, Prometheus y Jaeger
                quedan fuera.
Duracion      : 60 s estado estable | 120 s inyeccion | 90 s recuperacion.
Rollback      : temporizador duro (kill de stress-ng + liberacion del cgroup) y
                watchdog canary con condicion de parada.
"""
import json
import os
import signal
import subprocess
import threading
import time

import httpx

CG = "/sys/fs/cgroup/cpu/svcb"
CANARY = "http://127.0.0.1:8000/api/orders/1?qty=1"
EVENTS, CANARY_LOG = [], []
ABORT = threading.Event()
proc = None


def ev(name, detail=""):
    e = {"ts": round(time.time(), 3), "iso": time.strftime("%H:%M:%S"),
         "event": name, "detail": detail}
    EVENTS.append(e)
    print(f"[{e['iso']}] {name} {detail}", flush=True)


def sh(c):
    return subprocess.run(c, shell=True, capture_output=True, text=True).stdout.strip()


def setup_cgroup():
    os.makedirs(CG, exist_ok=True)
    open(f"{CG}/cpu.cfs_period_us", "w").write("100000")
    open(f"{CG}/cpu.cfs_quota_us", "w").write("100000")      # cuota = 1 CPU
    roots = sh("pgrep -f 'port 8001'").split()
    pids = list(roots)
    for r in roots:                                   # incluye los workers hijos
        pids += sh(f"pgrep -P {r}").split()
    pids = sorted(set(pids))
    for p in pids:
        try:
            open(f"{CG}/tasks", "w").write(p)
        except Exception as exc:
            print("no se pudo mover", p, exc)
    ev("PREPARACION", f"cgroup {CG} con cuota 1 CPU; PIDs de service-b: {pids}")


def inject():
    global proc
    proc = subprocess.Popen(
        ["stress-ng", "--cpu", "4", "--cpu-method", "matrixprod", "--timeout", "130s", "--metrics-brief"],
        stdout=open("logs/stress-ng.log", "w"), stderr=subprocess.STDOUT, preexec_fn=os.setsid)
    for p in [proc.pid] + sh(f"pgrep -P {proc.pid}").split():
        try:
            open(f"{CG}/tasks", "w").write(str(p))
        except Exception:
            pass
    ev("INYECCION", f"stress-ng --cpu 4 (matrixprod) dentro del cgroup de service-b, PID {proc.pid}")


def rollback(reason=""):
    global proc
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:
            pass
    ev("ROLLBACK", f"{reason} | stress-ng terminado; procesos restantes: '{sh('pgrep -c stress-ng')}'")


def watchdog():
    c = httpx.Client(timeout=12.0)
    fails = 0
    while not ABORT.is_set():
        t0 = time.perf_counter()
        try:
            code = c.get(CANARY).status_code
        except Exception:
            code = 0
        lat = (time.perf_counter() - t0) * 1000
        CANARY_LOG.append({"ts": round(time.time(), 2), "status": code, "latency_ms": round(lat, 1)})
        fails = fails + 1 if (code != 200 or lat > 8000) else 0
        if fails >= 5:
            ev("ABORT_CONDITION", f"5 canarios degradados seguidos (status={code}, {lat:.0f} ms)")
            rollback("disparado por el watchdog")
            ABORT.set()
            return
        time.sleep(2)


def main():
    setup_cgroup()
    threading.Thread(target=watchdog, daemon=True).start()
    ev("INICIO", "estado estable con cuota de 1 CPU")
    for _ in range(60):
        if ABORT.is_set():
            break
        time.sleep(1)
    ev("FASE_1", "agotamiento de CPU en el cgroup de service-b")
    inject()
    for _ in range(120):
        if ABORT.is_set():
            break
        time.sleep(1)
    if not ABORT.is_set():
        rollback("fin de la ventana programada")
    ABORT.set()
    ev("RECUPERACION", "observando el retorno al estado estable")
    time.sleep(90)
    ev("FIN", "")
    json.dump({"events": EVENTS, "canary": CANARY_LOG},
              open("results/exp2_timeline.json", "w"), indent=1, ensure_ascii=False)


main()
