#!/usr/bin/env python3
"""Analisis de un experimento: SLIs desde el cliente (CSV) y desde Prometheus."""
import csv
import json
import sys

import httpx

exp = sys.argv[1]                                    # exp1 / exp2 / exp3
csv_path = sys.argv[2]
PROM = "http://127.0.0.1:9090/api/v1/query_range"

tl = json.load(open(f"results/{exp}_timeline.json"))
events = tl["events"]
t0 = events[0]["ts"]
t1 = events[-1]["ts"]

rows = [r for r in csv.DictReader(open(csv_path))]
for r in rows:
    r["ts"] = float(r["ts"]); r["latency_ms"] = float(r["latency_ms"])
rows.sort(key=lambda r: r["ts"])


def pct(v, q):
    if not v:
        return float("nan")
    v = sorted(v)
    return v[min(len(v) - 1, int(q * len(v)))]


# ---- fases a partir de los eventos del timeline ----
marks = [e for e in events if e["event"] in
         ("INICIO", "FASE_1", "FASE_2", "ROLLBACK", "ABORT_CONDITION", "RECUPERACION", "FIN")]
fases = []
for i, m in enumerate(marks[:-1]):
    fases.append((m["event"], m["ts"], marks[i + 1]["ts"]))

print(f"\n=== {exp.upper()} — SLIs medidos en el cliente (open-loop) ===")
print(f"{'fase':<16}{'dur(s)':>7}{'n':>7}{'rps':>7}{'ok%':>8}{'p50':>9}{'p95':>10}{'p99':>10}{'max':>10}")
resumen = []
for name, a, b in fases:
    w = [r for r in rows if a <= r["ts"] < b]
    if not w:
        continue
    lat = [r["latency_ms"] for r in w]
    ok = sum(1 for r in w if r["status"] == "200")
    d = {"fase": name, "dur": round(b - a), "n": len(w), "rps": round(len(w) / (b - a), 1),
         "ok_pct": round(100 * ok / len(w), 2), "p50": round(pct(lat, .5), 1),
         "p95": round(pct(lat, .95), 1), "p99": round(pct(lat, .99), 1), "max": round(max(lat), 1),
         "t_ini": a, "t_fin": b}
    resumen.append(d)
    print(f"{name:<16}{d['dur']:>7}{d['n']:>7}{d['rps']:>7}{d['ok_pct']:>8}"
          f"{d['p50']:>9}{d['p95']:>10}{d['p99']:>10}{d['max']:>10}")

códigos = {}
for r in rows:
    códigos[r["status"] + ("/" + r["error"] if r["error"] else "")] = \
        códigos.get(r["status"] + ("/" + r["error"] if r["error"] else ""), 0) + 1
print("\ncodigos de respuesta:", códigos)

# ---- serie temporal de 10 s ----
serie = []
t = t0
while t < t1:
    w = [r for r in rows if t <= r["ts"] < t + 10]
    if w:
        lat = [r["latency_ms"] for r in w]
        serie.append({"t": round(t - t0), "rps": round(len(w) / 10, 1),
                      "p50": round(pct(lat, .5), 1), "p95": round(pct(lat, .95), 1),
                      "err_pct": round(100 * sum(1 for r in w if r["status"] != "200") / len(w), 2)})
    t += 10

# ---- SLIs desde Prometheus ----
Q = {
 "p95_service_a_ms": 'histogram_quantile(0.95, sum by (le) (rate(http_server_duration_milliseconds_bucket{job="service-a"}[30s])))',
 "p95_service_b_ms": 'histogram_quantile(0.95, sum by (le) (rate(http_server_duration_milliseconds_bucket{job="service-b"}[30s])))',
 "throughput_rps":   'sum(rate(http_server_duration_milliseconds_count{job="service-a"}[30s]))',
 "error_ratio":      'sum(rate(http_server_duration_milliseconds_count{job="service-a",http_status_code!="200"}[30s])) / clamp_min(sum(rate(http_server_duration_milliseconds_count{job="service-a"}[30s])),0.001)',
 "in_flight":        'sum(http_server_active_requests{job="service-a"})',
}
prom = {}
for k, q in Q.items():
    try:
        r = httpx.get(PROM, params={"query": q, "start": t0, "end": t1, "step": "10"}, timeout=20).json()
        prom[k] = [[float(a), float(b)] for a, b in (r["data"]["result"][0]["values"] if r["data"]["result"] else [])]
    except Exception as exc:
        prom[k] = []
        print("prom error", k, exc)

json.dump({"resumen": resumen, "serie": serie, "codigos": códigos, "prom": prom,
           "t0": t0, "events": events},
          open(f"results/{exp}_analisis.json", "w"), indent=1, ensure_ascii=False)
print(f"\nanalisis -> results/{exp}_analisis.json")
for k, v in prom.items():
    if v:
        vals = [x[1] for x in v]
        print(f"  {k:<20} min={min(vals):.2f}  max={max(vals):.2f}  n={len(vals)}")
