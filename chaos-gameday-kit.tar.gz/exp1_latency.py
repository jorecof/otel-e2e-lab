#!/usr/bin/env python3
"""
EXPERIMENTO 1 -- Inyeccion de latencia en la dependencia de inventario.

Fallo         : network latency sobre el enlace service-a -> service-b.
Inyector      : Toxiproxy 2.11 (toxina `latency`, stream downstream).
                El kernel del sandbox (Firecracker 6.18, sin modulos cargables)
                no expone sch_netem, por lo que se sustituye `tc netem` por
                Toxiproxy, que aplica el mismo modelo delay+jitter en el enlace.
                Equivalente en el lab OrbStack:
                  tc qdisc add dev eth0 root netem delay 400ms 100ms distribution normal
Blast radius  : exclusivamente el socket TCP service-a -> service-b (puerto 8901
                del inyector). Postgres, el OTel Collector, Prometheus, Jaeger y
                el trafico del cliente quedan fuera del radio.
Duracion      : 120 s estado estable | 90 s fase 1 (400 ms) | 90 s fase 2
                (2500 ms) | 120 s recuperacion  = 420 s.
Rollback      : (a) temporizador duro que elimina la toxina al cerrar la ventana
                (b) watchdog canary cada 2 s que aborta si se cumple la
                    condicion de parada (5 muestras seguidas con error o
                    latencia > 8000 ms).
"""
import json
import threading
import time

import httpx

TOXI = "http://127.0.0.1:8474/proxies/inventory/toxics"
CANARY = "http://127.0.0.1:8000/api/orders/1?qty=1"

EVENTS, CANARY_LOG = [], []
ABORT = threading.Event()
adm = httpx.Client(timeout=10.0)


def ev(name, detail=""):
    e = {"ts": round(time.time(), 3), "iso": time.strftime("%H:%M:%S"),
         "event": name, "detail": detail}
    EVENTS.append(e)
    print(f"[{e['iso']}] {name} {detail}", flush=True)


def inject(latency_ms, jitter_ms):
    rollback(silent=True)
    r = adm.post(TOXI, json={"name": "lat", "type": "latency", "stream": "downstream",
                             "attributes": {"latency": latency_ms, "jitter": jitter_ms}})
    ev("INYECCION", f"latency={latency_ms}ms jitter={jitter_ms}ms  [{r.status_code}] {r.text[:120]}")


def rollback(silent=False, reason=""):
    try:
        adm.delete(f"{TOXI}/lat")
    except Exception:
        pass
    if not silent:
        estado = adm.get(TOXI).text
        ev("ROLLBACK", f"{reason} | toxinas activas: {estado}")


def watchdog():
    c = httpx.Client(timeout=12.0)
    fails = 0
    while not ABORT.is_set():
        t0 = time.perf_counter()
        try:
            r = c.get(CANARY)
            code = r.status_code
        except Exception:
            code = 0
        lat = (time.perf_counter() - t0) * 1000
        CANARY_LOG.append({"ts": round(time.time(), 2), "status": code,
                           "latency_ms": round(lat, 1)})
        fails = fails + 1 if (code != 200 or lat > 8000) else 0
        if fails >= 5:
            ev("ABORT_CONDITION", f"5 canarios consecutivos degradados (ultimo status={code}, {lat:.0f} ms)")
            rollback(reason="disparado por el watchdog (abort condition)")
            ABORT.set()
            return
        time.sleep(2)


def wait(seconds):
    for _ in range(seconds):
        if ABORT.is_set():
            return
        time.sleep(1)


def main():
    threading.Thread(target=watchdog, daemon=True).start()
    ev("INICIO", "ventana de estado estable, sin fallo inyectado")
    wait(120)

    ev("FASE_1", "degradacion moderada de la dependencia de inventario")
    inject(400, 100)
    wait(90)

    if not ABORT.is_set():
        ev("FASE_2", "escalada controlada: latencia severa en la dependencia")
        inject(2500, 500)
        wait(90)

    if not ABORT.is_set():
        rollback(reason="fin de la ventana programada (temporizador duro)")
    ABORT.set()

    ev("RECUPERACION", "observando el retorno al estado estable")
    time.sleep(120)
    ev("FIN", "")

    json.dump({"events": EVENTS, "canary": CANARY_LOG},
              open("results/exp1_timeline.json", "w"), indent=1, ensure_ascii=False)
    print("timeline -> results/exp1_timeline.json")


main()
